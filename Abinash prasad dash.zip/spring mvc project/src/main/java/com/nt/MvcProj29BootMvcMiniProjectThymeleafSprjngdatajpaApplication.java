package com.nt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MvcProj29BootMvcMiniProjectThymeleafSprjngdatajpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MvcProj29BootMvcMiniProjectThymeleafSprjngdatajpaApplication.class, args);
	}

}
